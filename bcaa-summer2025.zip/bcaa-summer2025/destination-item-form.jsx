import { useState, useContext } from "react";
import Modal from "react-bootstrap/Modal";
import Button from "react-bootstrap/Button";
import Form from "react-bootstrap/Form";
import Alert from "react-bootstrap/Alert";
import { DestinationListContext } from "./destination-list-provider.jsx";

function DestinationItemForm({ destinationId, onCancel }) {
	const { handlerMap } = useContext(DestinationListContext);
	const [formData, setFormData] = useState({
      name: '',
      description: ''
	});
	const [error, setError] = useState(null);

	const handleSubmit = async () => {
		setError(null);
		if (!formData.name) return setError("Please enter a name.");
		if (!formData.description) return setError("Please enter a description.");


		// Build payload for schema
		const payload = {
			name: formData.name,
            description: formData.description
		};

		const result = await handlerMap.handleCreate(payload);
		if (result.ok) onCancel();
		else setError(result.error?.message || "Unknown error.");
	};

	return (
		<Modal show={true} onHide={onCancel}>
			<Modal.Header closeButton>
				<Modal.Title>Create Activity</Modal.Title>
			</Modal.Header>
			<Modal.Body>
				{error && <Alert variant="danger">{error}</Alert>}
				<Form>
					<Form.Group>
						<Form.Label>Destination Name</Form.Label>
						<Form.Control
							type="text"
							value={formData.name}
							maxLength={100}
							onChange={(e) => setFormData({ ...formData, name: e.target.value })}
						/>
					</Form.Group>

                  <Form.Group>
                    <Form.Label>Description Destination</Form.Label>
                    <Form.Control
                        type="text"
                        value={formData.description}
                        maxLength={100}
                        onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    />
                  </Form.Group>

				</Form>
			</Modal.Body>
			<Modal.Footer>
				<Button variant="secondary" onClick={onCancel}>Cancel</Button>
				<Button variant="primary" onClick={handleSubmit}>Save</Button>
			</Modal.Footer>
		</Modal>
	);
}

export default DestinationItemForm;
