import { Card, Button, Row, Col } from "react-bootstrap";

function DestinationItem(props) {
	const {
		destination,
		onDelete,
		onAddActivity
	} = props;

	return (
		<Card className="mb-3 shadow-sm">
			<Card.Body>
				<Card.Title>{destination.name}</Card.Title>
				<Card.Text>{destination.description}</Card.Text>
				<Row>
					<Col xs="auto">
						<Button variant="danger" onClick={() => onDelete(destination)}>
							Delete
						</Button>
					</Col>
					<Col xs="auto">
						<Button variant="primary" onClick={() => onAddActivity(destination)}>
							Add Activity
						</Button>
					</Col>
				</Row>
			</Card.Body>
		</Card>
	);
}

export default DestinationItem;
