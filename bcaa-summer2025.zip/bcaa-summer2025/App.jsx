import Dashboard from "./dashboard";
import DestinationListProvider from "./destination-list-provider";

function App() {
  return (
      <DestinationListProvider>
        <Dashboard/>
      </DestinationListProvider>

  )
}

export default App
